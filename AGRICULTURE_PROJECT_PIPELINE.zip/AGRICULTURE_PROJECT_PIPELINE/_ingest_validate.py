# Databricks notebook source
# 01_ingest_validate

from pyspark.sql import functions as F

# ✅ Load dataset from Databricks table
SOURCE_TABLE = "workspace.default.agri_big_data_3000"
df = spark.table(SOURCE_TABLE)

# Normalize column names
for c in df.columns:
    df = df.withColumnRenamed(c, c.strip().lower().replace(" ", "_"))

print("✅ Columns:", df.columns)
print(f"✅ Row count: {df.count()}")

# Quick schema and sample
df.printSchema()
display(df.limit(5))

# Basic null checks
dq = {}
required_cols = ["region","crop","date","post_text","emotion"]
for c in required_cols:
    dq[c] = df.filter(F.col(c).isNull() | (F.trim(F.col(c)) == "")).count()
print("❗ Missing counts:", dq)

df.createOrReplaceTempView("raw_agri")
print("✅ Temp view 'raw_agri' created.")
