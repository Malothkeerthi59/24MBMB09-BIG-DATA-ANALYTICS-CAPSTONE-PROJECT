# Databricks notebook source
# Databricks notebook source
# ======================================================
# AGRICULTURE PROJECT MASTER PIPELINE (FINAL VERSION)
# Big Data Analytics - Databricks Orchestrator
# ======================================================

from datetime import datetime

print("🚀 Starting Agriculture Project Master Pipeline at:", datetime.now())

# -------------------------------------------------------------------
# 1️⃣ Define notebook paths (use your exact renamed paths)
# -------------------------------------------------------------------
notebook_paths = {
    "ingest": "/Workspace/Users/malothkeerthi123@gmail.com/AGRICULTURE_PROJECT_PIPELINE/_ingest_validate",
    "transform": "/Workspace/Users/malothkeerthi123@gmail.com/AGRICULTURE_PROJECT_PIPELINE/transform_canonical",
    "features": "/Workspace/Users/malothkeerthi123@gmail.com/AGRICULTURE_PROJECT_PIPELINE/feature_engineering",
    "model": "/Workspace/Users/malothkeerthi123@gmail.com/AGRICULTURE_PROJECT_PIPELINE/model_training",
    "alerts": "/Workspace/Users/malothkeerthi123@gmail.com/AGRICULTURE_PROJECT_PIPELINE/alerts_recommendation"
}

# -------------------------------------------------------------------
# 2️⃣ Function to execute notebooks safely
# -------------------------------------------------------------------
def run_notebook(name, timeout=3600):
    """Runs a single notebook and logs its status."""
    print("\n----------------------------------------------")
    print(f"▶️ Running stage: {name}")
    print("----------------------------------------------")
    try:
        result = dbutils.notebook.run(notebook_paths[name], timeout)
        print(f"✅ Stage '{name}' completed successfully at {datetime.now()}")
        return {"stage": name, "status": "Success", "timestamp": str(datetime.now())}
    except Exception as e:
        print(f"❌ Error in stage '{name}': {e}")
        return {"stage": name, "status": f"Failed - {e}", "timestamp": str(datetime.now())}

# -------------------------------------------------------------------
# 3️⃣ Execute all stages sequentially
# -------------------------------------------------------------------
pipeline_stages = ["ingest", "transform", "features", "model", "alerts"]
results = []

for stage in pipeline_stages:
    results.append(run_notebook(stage))

# -------------------------------------------------------------------
# 4️⃣ Display pipeline execution summary
# -------------------------------------------------------------------
print("\n===============================================")
print("📊 PIPELINE EXECUTION SUMMARY")
print("===============================================")
for r in results:
    print(f"{r['stage'].ljust(12)} | {r['status'].ljust(30)} | {r['timestamp']}")
print("===============================================")
print("🎯 AGRICULTURE PROJECT MASTER PIPELINE COMPLETED")
print("End Time:", datetime.now())
print("===============================================")
