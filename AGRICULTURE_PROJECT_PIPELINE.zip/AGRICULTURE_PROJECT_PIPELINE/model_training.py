# Databricks notebook source
# 04_model_training — Self-Contained (Serverless Safe)
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.regression import RandomForestRegressor
from pyspark.ml.clustering import KMeans
from pyspark.ml import Pipeline

# ------------------------------------------------------------------
# 1️⃣ LOAD DATA FROM YOUR MAIN TABLE
# ------------------------------------------------------------------
df = spark.table("workspace.default.agri_big_data_3000")

# Normalize column names
for c in df.columns:
    df = df.withColumnRenamed(c, c.strip().lower().replace(" ", "_"))

# ------------------------------------------------------------------
# 2️⃣ ENSURE REQUIRED COLUMNS EXIST
# ------------------------------------------------------------------
expected_cols = ["region","crop","post_text","emotion","sentiment_score",
                 "price","demand_index","temperature","rainfall","date"]
for colname in expected_cols:
    if colname not in df.columns:
        df = df.withColumn(colname, F.lit(None))

# ------------------------------------------------------------------
# 3️⃣ SAFE TIMESTAMP CONVERSION
# ------------------------------------------------------------------
df = df.withColumn(
    "event_ts",
    F.coalesce(F.expr("try_to_timestamp(date, 'yyyy-MM-dd HH:mm:ss')"), F.current_timestamp())
)

# ------------------------------------------------------------------
# 4️⃣ ENSURE sentiment_score IS NUMERIC
# ------------------------------------------------------------------
if "sentiment_score" not in df.columns or dict(df.dtypes).get("sentiment_score") != "double":
    df = df.withColumn(
        "sentiment_score",
        F.when(F.col("emotion").rlike("positive|happy|joy|optimistic"), 1)
         .when(F.col("emotion").rlike("negative|sad|angry|fear|frustrated"), -1)
         .otherwise(0)
    )

# ------------------------------------------------------------------
# 5️⃣ CREATE DAILY AGGREGATED FEATURE TABLE (agri_daily_region)
# ------------------------------------------------------------------
pest_keywords = ["pest","disease","infection","infestation","blight","wilt","aphid","rust","borer","damage"]
regex = "|".join([rf"(?i)\b{k}\b" for k in pest_keywords])
df = df.withColumn("pest_flag", F.when(F.col("post_text").rlike(regex), 1).otherwise(0))

daily = (
    df.withColumn("day", F.date_trunc("day", "event_ts"))
      .groupBy("region", "crop", "day")
      .agg(
          F.count("*").alias("post_count"),
          F.sum("pest_flag").alias("pest_mentions"),
          F.avg("sentiment_score").alias("avg_sentiment"),
          F.avg("price").alias("avg_price"),
          F.avg("demand_index").alias("avg_demand")
      )
)

# Add rolling stats
w = Window.partitionBy("region").orderBy("day").rowsBetween(-2, 0)
daily = (
    daily.withColumn("mean_3d", F.avg("pest_mentions").over(w))
         .withColumn("std_3d", F.stddev("pest_mentions").over(w))
         .withColumn("z_score",
                     F.when(F.col("std_3d") > 0,
                            (F.col("pest_mentions") - F.col("mean_3d")) / F.col("std_3d"))
                     .otherwise(0))
)
daily.createOrReplaceTempView("agri_daily_region")
print("✅ Feature view 'agri_daily_region' created successfully.")
display(daily.limit(10))

# ------------------------------------------------------------------
# 6️⃣ PRICE NOWCASTING MODEL (Random Forest)
# ------------------------------------------------------------------
features = daily
w = Window.partitionBy("crop").orderBy("day")

features = features.withColumn("next_price", F.lead("avg_price").over(w))
features = features.withColumn("price_change", F.col("next_price") - F.col("avg_price")).na.drop()

if features.count() > 10:
    assembler = VectorAssembler(
        inputCols=["avg_sentiment", "post_count", "avg_demand"],
        outputCol="features"
    )
    rf = RandomForestRegressor(featuresCol="features", labelCol="price_change", numTrees=40, maxDepth=6)
    pipeline = Pipeline(stages=[assembler, rf])
    model = pipeline.fit(features)
    preds = model.transform(features)
    preds.createOrReplaceTempView("agri_price_predictions")
    print("✅ Price prediction model trained successfully.")
    display(preds.select("crop", "day", "avg_price", "next_price", "prediction").limit(100))
else:
    print("⚠️ Not enough data to train the price prediction model.")

# ------------------------------------------------------------------
# 7️⃣ DEMAND CLUSTERING MODEL (KMeans)
# ------------------------------------------------------------------
agg = (
    features.groupBy("region", "crop")
            .agg(
                F.avg("avg_sentiment").alias("avg_sent"),
                F.avg("avg_price").alias("avg_price"),
                F.sum("post_count").alias("posts"),
                F.avg("avg_demand").alias("avg_demand")
            )
            .na.fill(0)
)

va = VectorAssembler(inputCols=["avg_sent", "avg_price", "posts", "avg_demand"], outputCol="vec")
vec_df = va.transform(agg)
kmeans = KMeans(k=4, featuresCol="vec", seed=42)
model_km = kmeans.fit(vec_df)
clusters = model_km.transform(vec_df)
clusters.createOrReplaceTempView("agri_demand_clusters")

print("✅ Demand clustering completed successfully.")
display(clusters.limit(50))

# ------------------------------------------------------------------
# 8️⃣ MODEL QUALITY CHECK (Optional)
# ------------------------------------------------------------------
if "preds" in locals():
    mse = preds.select(F.mean(F.pow(F.col("prediction") - F.col("price_change"), 2)).alias("mse")).collect()[0]["mse"]
    print(f"✅ Model Mean Squared Error (MSE): {mse:.4f}")
