# Databricks notebook source
# 05_alerts_recommendation — Self-contained and serverless-safe

from pyspark.sql import functions as F
from pyspark.sql.window import Window

# ------------------------------------------------------------------
# 1️⃣ LOAD MAIN DATASET
# ------------------------------------------------------------------
df = spark.table("workspace.default.agri_big_data_3000")

# Normalize column names
for c in df.columns:
    df = df.withColumnRenamed(c, c.strip().lower().replace(" ", "_"))

# ------------------------------------------------------------------
# 2️⃣ ENSURE REQUIRED COLUMNS EXIST
# ------------------------------------------------------------------
expected_cols = ["region","crop","post_text","emotion","sentiment_score",
                 "price","demand_index","temperature","rainfall","date"]
for colname in expected_cols:
    if colname not in df.columns:
        df = df.withColumn(colname, F.lit(None))

# ------------------------------------------------------------------
# 3️⃣ SAFE TIMESTAMP CONVERSION
# ------------------------------------------------------------------
df = df.withColumn(
    "event_ts",
    F.coalesce(F.expr("try_to_timestamp(date, 'yyyy-MM-dd HH:mm:ss')"), F.current_timestamp())
)

# ------------------------------------------------------------------
# 4️⃣ DERIVE sentiment_score IF MISSING
# ------------------------------------------------------------------
if "sentiment_score" not in df.columns or dict(df.dtypes).get("sentiment_score") != "double":
    df = df.withColumn(
        "sentiment_score",
        F.when(F.col("emotion").rlike("positive|happy|joy|optimistic"), 1)
         .when(F.col("emotion").rlike("negative|sad|angry|fear|frustrated"), -1)
         .otherwise(0)
    )

# ------------------------------------------------------------------
# 5️⃣ PEST DETECTION
# ------------------------------------------------------------------
pest_keywords = ["pest","disease","infection","infestation","blight","wilt","aphid","rust","borer","damage"]
regex = "|".join([rf"(?i)\b{k}\b" for k in pest_keywords])
df = df.withColumn("pest_flag", F.when(F.col("post_text").rlike(regex), 1).otherwise(0))

# ------------------------------------------------------------------
# 6️⃣ BUILD DAILY AGGREGATES (like agri_daily_region)
# ------------------------------------------------------------------
daily = (
    df.withColumn("day", F.date_trunc("day", "event_ts"))
      .groupBy("region", "crop", "day")
      .agg(
          F.count("*").alias("post_count"),
          F.sum("pest_flag").alias("pest_mentions"),
          F.avg("sentiment_score").alias("avg_sentiment"),
          F.avg("price").alias("avg_price"),
          F.avg("demand_index").alias("avg_demand")
      )
)

# Add rolling anomaly metrics
w = Window.partitionBy("region").orderBy("day").rowsBetween(-2, 0)
daily = (
    daily.withColumn("mean_3d", F.avg("pest_mentions").over(w))
         .withColumn("std_3d", F.stddev("pest_mentions").over(w))
         .withColumn("z_score",
                     F.when(F.col("std_3d") > 0,
                            (F.col("pest_mentions") - F.col("mean_3d")) / F.col("std_3d"))
                     .otherwise(0))
         .withColumn("pest_anomaly", F.when(F.col("z_score") > 1.0, True).otherwise(False))
)

daily.createOrReplaceTempView("agri_daily_region")
print("✅ 'agri_daily_region' rebuilt successfully for alerts stage.")
display(daily.limit(10))

# ------------------------------------------------------------------
# 7️⃣ PEST ALERTS
# ------------------------------------------------------------------
alerts_pest = (
    daily.filter("pest_anomaly = true")
         .select("region", "crop", "day", "pest_mentions", "z_score")
         .withColumn("alert_reason", F.lit("Pest Outbreak Spike"))
         .withColumn("severity", F.when(F.col("pest_mentions") > 5, "high").otherwise("medium"))
         .withColumn("recommendation", F.lit("Advise immediate pest control measures"))
)

# ------------------------------------------------------------------
# 8️⃣ SENTIMENT ALERTS
# ------------------------------------------------------------------
sent = (
    df.groupBy("region")
      .agg(F.avg("sentiment_score").alias("avg_sent"))
)
alerts_sent = (
    sent.filter("avg_sent < 0")
        .select("region", "avg_sent")
        .withColumn("alert_reason", F.lit("Low Farmer Sentiment"))
        .withColumn("severity", F.lit("medium"))
        .withColumn("recommendation", F.lit("Engage with farmers via advisory and support programs"))
        .withColumn("crop", F.lit(None).cast("string"))
        .withColumn("day", F.lit(None).cast("timestamp"))
)

# ------------------------------------------------------------------
# 9️⃣ MERGE ALERTS
# ------------------------------------------------------------------
final_alerts = (
    alerts_pest.select("region", "crop", "day", "alert_reason", "severity", "recommendation")
    .unionByName(
        alerts_sent.select("region", "crop", "day", "alert_reason", "severity", "recommendation"),
        allowMissingColumns=True
    )
)

# ------------------------------------------------------------------
# 🔟 OUTPUT & VISUALIZATION
# ------------------------------------------------------------------
print("✅ Final Alerts Generated:")
display(final_alerts.orderBy("severity", "region", "day"))

# Optional export (safe for serverless)
out_path = "/tmp/agri_alerts_output.csv"
final_alerts.toPandas().to_csv(out_path, index=False)
print(f"📁 Alerts exported to: {out_path}")
