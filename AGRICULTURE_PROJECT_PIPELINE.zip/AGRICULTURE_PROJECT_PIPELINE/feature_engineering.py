# Databricks notebook source
# 03_feature_engineering — Fixed version for serverless Databricks

from pyspark.sql import functions as F
from pyspark.sql.window import Window

# ✅ Load directly from your main dataset
df = spark.table("workspace.default.agri_big_data_3000")

# Normalize all column names
for c in df.columns:
    df = df.withColumnRenamed(c, c.strip().lower().replace(" ", "_"))

# ✅ Handle missing columns gracefully
expected_cols = ["region","crop","post_text","emotion","sentiment_score","price","demand_index","temperature","rainfall","date"]
for colname in expected_cols:
    if colname not in df.columns:
        df = df.withColumn(colname, F.lit(None))

# ✅ Safe timestamp conversion
df = df.withColumn(
    "event_ts",
    F.coalesce(F.expr("try_to_timestamp(date, 'yyyy-MM-dd HH:mm:ss')"), F.current_timestamp())
)

# ✅ Ensure sentiment_score numeric
if "sentiment_score" not in df.columns or dict(df.dtypes)["sentiment_score"] != "double":
    df = df.withColumn(
        "sentiment_score",
        F.when(F.col("emotion").rlike("positive|happy|joy|optimistic"), 1)
         .when(F.col("emotion").rlike("negative|sad|angry|fear|frustrated"), -1)
         .otherwise(0)
    )

# ✅ Make sure post_text exists
if "post_text" not in df.columns:
    # Try to find a similar column name automatically
    alt_col = [c for c in df.columns if "text" in c.lower()]
    if len(alt_col) > 0:
        df = df.withColumnRenamed(alt_col[0], "post_text")
    else:
        df = df.withColumn("post_text", F.lit(""))

# ✅ Detect pest-related keywords in post_text or emotion
pest_keywords = ["pest","disease","infection","infestation","blight","wilt","aphid","rust","borer","damage"]
regex = "|".join([rf"(?i)\b{k}\b" for k in pest_keywords])

df = df.withColumn("pest_flag",
                   F.when(
                       F.col("post_text").rlike(regex) | F.col("emotion").rlike(regex),
                       1
                   ).otherwise(0))

# ✅ Daily aggregation by region & crop
daily = (df.withColumn("day", F.date_trunc("day","event_ts"))
           .groupBy("region","crop","day")
           .agg(
               F.count("*").alias("post_count"),
               F.sum("pest_flag").alias("pest_mentions"),
               F.avg("sentiment_score").alias("avg_sentiment"),
               F.avg("price").alias("avg_price"),
               F.avg("demand_index").alias("avg_demand")
           )
        )

# ✅ Rolling 3-day z-score for anomaly detection
w = Window.partitionBy("region").orderBy("day").rowsBetween(-2,0)
daily = (daily.withColumn("mean_3d", F.avg("pest_mentions").over(w))
               .withColumn("std_3d", F.stddev("pest_mentions").over(w))
               .withColumn("z_score",
                           F.when(F.col("std_3d")>0,
                                  (F.col("pest_mentions")-F.col("mean_3d"))/F.col("std_3d"))
                           .otherwise(F.lit(0)))
               .withColumn("pest_anomaly", F.when(F.col("z_score")>1.0, True).otherwise(False))
        )

# ✅ Register as temp view
daily.createOrReplaceTempView("agri_daily_region")
print("✅ Feature view 'agri_daily_region' created successfully.")

# ✅ Display sample output
display(daily.orderBy("region","day").limit(50))
