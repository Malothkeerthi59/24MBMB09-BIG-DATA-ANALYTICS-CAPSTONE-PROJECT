# Databricks notebook source
# 02_transform_canonical — FIXED VERSION

from pyspark.sql import functions as F
from pyspark.sql.types import DoubleType

# ✅ Load again from your original Databricks table
SOURCE_TABLE = "workspace.default.agri_big_data_3000"
df = spark.table(SOURCE_TABLE)

# Normalize column names
for c in df.columns:
    df = df.withColumnRenamed(c, c.strip().lower().replace(" ", "_"))

# ✅ Safe timestamp conversion using try_to_timestamp
df = df.withColumn(
    "event_ts",
    F.expr("try_to_timestamp(date, 'yyyy-MM-dd HH:mm:ss')")
)
df = df.withColumn("event_ts", F.coalesce(F.col("event_ts"), F.current_timestamp()))

# Ensure required columns exist
for colname in ["region","crop","post_text","emotion","sentiment_score","price","demand_index","temperature","rainfall"]:
    if colname not in df.columns:
        df = df.withColumn(colname, F.lit(None))

# Normalize emotion text
df = df.withColumn("emotion_norm", F.lower(F.coalesce(F.col("emotion"), F.lit(""))))

# Derive sentiment_score if missing
if df.filter(F.col("sentiment_score").isNotNull()).count() == 0:
    df = df.withColumn(
        "sentiment_score",
        F.when(F.col("emotion_norm").rlike("positive|happy|joy|optimistic"), 1)
         .when(F.col("emotion_norm").rlike("negative|sad|angry|fear|frustrated"), -1)
         .otherwise(0)
    )

# Cast numeric columns
for col in ["sentiment_score","price","demand_index","temperature","rainfall"]:
    if col in df.columns:
        df = df.withColumn(col, F.col(col).cast(DoubleType()))

# Label for sentiment
df = df.withColumn("sentiment_label",
                   F.when(F.col("sentiment_score")>0,"positive")
                    .when(F.col("sentiment_score")<0,"negative")
                    .otherwise("neutral"))

# ✅ Register canonical dataset
df.createOrReplaceTempView("agri_canonical")
print("✅ Canonical view 'agri_canonical' created successfully.")
display(df.select("region","crop","post_text","event_ts","sentiment_score","price").limit(10))
